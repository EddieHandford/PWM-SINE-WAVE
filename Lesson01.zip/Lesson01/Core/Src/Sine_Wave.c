/*
 * Sine_Wave.c
 *
 *  Created on: Oct 18, 2020
 *      Author: Eddie
 */

#include "Sine_Wave.h"
#include <math.h>

float Sine_Wave ( int Frequency , int Amplitude , int Time){

	float Float_Amplitude = (float) Amplitude;
	float Float_Frequency = (float) Frequency;
	float Float_Time = (float) Time;

	float Val = (Float_Amplitude*(sin(Float_Frequency*2*3.141 * Float_Time/1000 )) + 1)/2;

	return Val;
}
