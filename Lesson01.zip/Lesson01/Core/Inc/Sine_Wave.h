//#pragma once

#ifndef Sine_Wave
#define Sine_Wave

float Sine_Wave (int, int , int);

#endif